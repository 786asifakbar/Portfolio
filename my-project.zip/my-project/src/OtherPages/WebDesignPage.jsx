// Import necessary libraries
import React from 'react';


// React component for the web design page
const WebDesignPage = () => {
  return (
<>
   <div className="container mx-auto flex flex-col-reverse md:flex-row items-center justify-between 
   mt-1 py-8 bg-blue-800 text-wrap h-screen shadow-xl text-slate-100">

      {/* Left side with the image */}
      <div className="md:w-1/2">
        <img className="object-cover w-auto h-full rounded-e-full" 
        src="https://img.freepik.com/free-vector/website-creator-concept-illustration_114360-2766.jpg?size=626&ext=jpg&uid=R134050431&ga=GA1.1.1643376567.1705693399&semt=ais" 
        alt="Web Design" 
         />
      </div>


      {/* Right side with content */}
      <div className="md:w-1/2 p-8">
        <h1 className="text-4xl font-bold mb-4 text-white">Professional and Beautiful Websites</h1>
        <p className="text-white mb-6">
          Welcome to my web design services! I specialize in creating professional and beautiful websites using the MERN Stack (MongoDB, Express.js, React.js, Node.js). Whether you need a personal portfolio, e-commerce site, or a complex web application, I have the skills and expertise to bring your vision to life.
        </p>

        <p className="text-white mb-6">
          With a keen eye for design and a passion for clean code, I ensure that your website not only looks stunning but also performs seamlessly. I pay attention to every detail, from user experience to responsive design, to provide a website that engages your audience effectively.
        </p>

        <p className="text-text mb-6">
          My MERN Stack development services cover the entire process, from concept and design to implementation and deployment. I work closely with clients to understand their goals and deliver a tailored solution that meets their unique requirements.
        </p>

        <p className="text-white">
          Let's collaborate to create a web presence that not only meets but exceeds your expectations. Contact me to get started on your journey to a professional and beautiful website.
        </p>
      </div>
    </div>
</>
);
};

export default WebDesignPage;
