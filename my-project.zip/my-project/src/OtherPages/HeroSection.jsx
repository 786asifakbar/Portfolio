// HeroSection.js
import React from 'react';



const HeroSection = () => {
  return (
    <div className="container mx-auto flex flex-col-reverse md:flex-row 
    items-center justify-between p-8 bg-blue-800 text-wrap shadow-xl
    w-full h-screen bg-no-repeat bg-center
    bg-[url()]">
      
      {/* Left Side (6 cols) */}
      <div className="md:w-6/12 ml-40 mt-52">
      <h4 className="text-2xl font-bold mb-2 animate-bounce text-green-500">Welcome to My Portfolio</h4>
      <h1 className="text-7xl font-bold mb-4 text-pretty text-white">Asif Akbar </h1>
        <p className="text-white mb-4">
        I am a passionate MEAN Stack Developer with experience in building
        robust web applications.
        </p>
        <button className="bg-white text-blue-800 px-4 py-2 rounded-md hover:bg-green-500 hover:text-white">
          <a href='./about'> Read More </a>
        </button>
      </div>

      {/* Right Side (6 cols) */}
      <div className="md:w-6/12 mt-4 md:mt-0 ">
        <img  className="w-auto h-auto rounded-full"  
          src=".\src\OtherPages\asif.PNG"  // Replace with the actual path to your image
          alt="Hero Image"
         
        />
      </div>
    </div>
  );
};

export default HeroSection;
