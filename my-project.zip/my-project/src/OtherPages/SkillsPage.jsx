// Import necessary libraries
import React from 'react';

// React component for the skills page
const SkillsPage = () => {
  return (
    <div className="container min-h-screen mx-auto items-center p-6 
    justify-between bg-blue-800 text-wrap mt-1 shadow-xl">

      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <h1 className="text-4xl font-bold col-span-full ">Skills</h1>

        {/* HTML Skill */}
        <div className="mb-6">
          <h2 className="text-xl font-semibold mb-2">HTML</h2>
          <div className="flex items-center">
            <div className="bg-gray-300 h-4 rounded-full flex-grow">
              <div className="bg-green-500 h-full rounded-e-full"></div>
            </div>
            <span className="ml-4">80%</span>
          </div>
        </div>

        {/* CSS Skill */}
        <div className="mb-6">
          <h2 className="text-xl font-semibold mb-2">CSS</h2>
          <div className="flex items-center">
            <div className="bg-gray-300 h-4 rounded-full flex-grow">
              <div className="bg-green-500 h-full rounded-e-full"></div>
            </div>
            <span className="ml-4">75%</span>
          </div>
        </div>

        {/* JavaScript Skill */}
        <div className="mb-6">
          <h2 className="text-xl font-semibold mb-2">JavaScript</h2>
          <div className="flex items-center">
            <div className="bg-gray-300 h-4 rounded-full flex-grow">
              <div className="bg-green-500 h-full rounded-e-full"></div>
            </div>
            <span className="ml-4">80%</span>
          </div>
        </div>

        {/* React Skill */}
        <div className="mb-6">
          <h2 className="text-xl font-semibold mb-2">React</h2>
          <div className="flex items-center">
            <div className="bg-gray-300 h-4 rounded-full flex-grow">
              <div className="bg-green-500 h-full rounded-e-full"></div>
            </div>
            <span className="ml-4">70%</span>
          </div>
        </div>

         {/* MangoDB Skill */}
         <div className="mb-6">
          <h2 className="text-xl font-semibold mb-2">MangoDB</h2>
          <div className="flex items-center">
            <div className="bg-gray-300 h-4 rounded-full flex-grow">
              <div className="bg-green-500 h-full rounded-e-full"></div>
            </div>
            <span className="ml-4">50%</span>
          </div>
        </div>

 {/* Express Skill */}
 <div className="mb-6">
          <h2 className="text-xl font-semibold mb-2">Express</h2>
          <div className="flex items-center">
            <div className="bg-gray-300 h-4 rounded-full flex-grow">
              <div className="bg-green-500 h-full rounded-e-full"></div>
            </div>
            <span className="ml-4">50%</span>
          </div>
        </div>

 {/* Node Skill */}
 <div className="mb-6">
          <h2 className="text-xl font-semibold mb-2">Nodejs</h2>
          <div className="flex items-center">
            <div className="bg-gray-300 h-4 rounded-full flex-grow">
              <div className="bg-green-500 h-full rounded-e-full"></div>
            </div>
            <span className="ml-4">50%</span>
          </div>
        </div>

 {/* Tailwindcss Skill */}
 <div className="mb-6">
          <h2 className="text-xl font-semibold mb-2">Tailwindcss</h2>
          <div className="flex items-center">
            <div className="bg-gray-300 h-4 rounded-full flex-grow">
              <div className="bg-green-500 h-full rounded-e-full"></div>
            </div>
            <span className="ml-4">70%</span>
          </div>
        </div>

 {/* Bootstrap Skill */}
 <div className="mb-6">
          <h2 className="text-xl font-semibold mb-2">Bootstrap</h2>
          <div className="flex items-center">
            <div className="bg-gray-300 h-4 rounded-full flex-grow">
              <div className="bg-green-500 h-full rounded-e-full"></div>
            </div>
            <span className="ml-4">80%</span>
          </div>
        </div>




      </div>
    </div>
  );
};

export default SkillsPage;
