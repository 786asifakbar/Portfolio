// ServicePage.js
import React from "react";


const servicesData = [
  {
    
    id: 1,
    icon: "", // Replace with your actual icon image
    title: "Service 1",
    description: "Description of Service 1.",
  },
  {
    id: 2,
    icon: "icon-service-2.svg", // Replace with your actual icon image
    title: "Service 2",
    description: "Description of Service 2.",
  },
  {
    id: 3,
    icon: "icon-service-3.svg", // Replace with your actual icon image
    title: "Service 3",
    description: "Description of Service 3.",
  },
  // Add more services as needed
];

const ServicePage = () => {
  return (
    <div className="container mx-auto mt-8 p-8">
      <h2 className="text-3xl font-semibold mb-6">Our Services</h2>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {servicesData.map((service) => (
          <div key={service.id} className="p-4 border rounded-md">
            <img
              src={service.icon}
              alt={service.title}
              className="w-16 h-16 mx-auto mb-4"
            />
            <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
            <p className="text-white">{service.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ServicePage;
