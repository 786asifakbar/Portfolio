// src/App.js
import React from 'react';
import { Route, Routes } from 'react-router-dom';
import Header from './component/Header';
import Home from './pages/Home';
import Projects from './pages/Projects';
import Contact from './pages/Contact';
import About from './pages/About';
import Footer from './component/Footer';




const App = () => {
  return (
    <> 
      <div className='bg-blue-800 text-white p-8'>   
        <Header />
        <Routes> 
          <Route path="/" exact Component={Home} />,
          <Route path="/about" Component={About} />,
          <Route path="/projects" Component={Projects} />,
          <Route path="/contact" Component={Contact} />,
          </Routes>
          <Footer />
     </div>
    </>
  );
};

export default App;