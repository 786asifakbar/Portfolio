// Footer.js

import React from 'react';
import { FaLinkedin } from "react-icons/fa";
import { FaFacebook } from "react-icons/fa";
import { FaInstagramSquare } from "react-icons/fa";
import { FaGithub } from "react-icons/fa6";


const Footer = () => {
  return (
    <> 
    <footer className="bg-blue-800 text-white py-10 px-48  ">
      <div className="container mx-auto flex flex-wrap justify-between border-t">
        {/* About Us */}
        <div className="w-full md:w-1/3  mb-4 md:mb-0">
          <h2 className="text-lg font-bold mb-2">About Us</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </div>

        {/* Contact Us */}
        <div className="w-full md:w-1/3 mb-4 md:mb-0">
          <h2 className="text-lg font-bold mb-2">Contact Us</h2>
          <p>Email: asifakbar1311@outlook.com </p>
          <p>Phone: +92-315-3933660 </p>
        </div>

        {/* Social Media */}
        <div className="w-full md:w-1/3">
          <h2 className="text-lg font-bold mb-2">Social Media</h2>
          <div className="flex space-x-4">          
          <a href="https://www.linkedin.com" className="text-white hover:text-gray-400">
              <FaLinkedin />
            </a>
        
            <a href="https://www.facebook.com" className="text-white hover:text-gray-400">
            <FaFacebook />
            </a>

            <a href="https://www.github.com" className="text-white hover:text-gray-400">
            <FaGithub />
            </a>

            <a href="https://www.instagram.com" className="text-white hover:text-gray-400">
              < FaInstagramSquare />
            </a>
          </div>
        </div>
      </div>
    </footer>
    </>
  );
};

export default Footer;
