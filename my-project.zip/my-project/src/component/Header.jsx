// Header.js
import React from 'react';
import { NavLink } from 'react-router-dom';


const Header = () => {
  return (
    <header className="bg-blue-800 py-10 mx-52 border-b">
      <nav className="container mx-auto flex items-center justify-between">
        {/* Logo */}
        <NavLink to="/" className="text-white text-lg font-bold">
          <img className='w-40' 
            src='../src/assets/logo.PNG'alt='logo Here' />
        </NavLink>

        {/* Navigation Links */}
        <div className="hidden md:flex space-x-6">
          <NavLink to="/" className="text-white">
            Home
          </NavLink>
          <NavLink to="/about" className="text-white">
            About
          </NavLink>

          <NavLink to="/projects" className="text-white">
            Projects
          </NavLink>

          <NavLink to="/contact" className="text-white">
            Contact
          </NavLink>
        </div>

        {/* Responsive Navigation (Hamburger Menu) */}
        <div className="md:hidden">
          <button
            className="text-white focus:outline-none"
            // Add onClick handler to toggle the menu on button click
          >
            <svg
              className="h-6 w-6"
              fill="none"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path d="M4 6h16M4 12h16m-7 6h7"></path>
            </svg>
          </button>
        </div>
      </nav>
    </header>
  );
};

export default Header;
