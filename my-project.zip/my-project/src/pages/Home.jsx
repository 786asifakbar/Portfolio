// src/components/Home.js
import React from 'react';
import HeroSection from '../OtherPages/HeroSection';
import WebDesignPage from '../OtherPages/WebDesignPage';
import About from './About';
import SkillsPage from '../OtherPages/SkillsPage';
import ServicePage from '../OtherPages/ServicesPage';



const Home = () => {
  return (
    <section className="bg-blue-800">
    
    <HeroSection />
    <WebDesignPage />
    <SkillsPage/>
   <ServicePage />
    </section>
  );
};

export default Home;
