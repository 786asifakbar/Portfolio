import React from 'react';


const Projects = () => {
  
  return (
<> 
<div className="container mx-auto py-10 bg-blue-800">
      <div className="flex flex-col md:flex-row">
        {/* First Column (Video) */}
        <div className="md:w-1/3 mb-4 md:mb-0 mr-5">
          <div className="aspect-w-16 aspect-h-9">
            <video className="w-full h-full object-cover" controls autoPlay loop>
              <source src="https://www.shutterstock.com/shutterstock/videos/1104507485/preview/stock-footage-drone-hyperlapse-of-king-abdullah-financial-district-kafd-at-night-riyadh-city-saudi-arabia.webm" 
              type="video/mp4" />
              Your browser does not support the video tag.
              <div>
             </div>          
            </video>
            <h2 className="text-xl font-bold mb-2">Project Details</h2>
             <p>Project description goes here.</p>
          </div>
        </div>


        {/* Second Column */}
         <div className="md:w-1/3 mb-4 md:mb-0 mr-5">
           <div className="aspect-w-16 aspect-h-9">
            <video className="w-full h-full object-cover" controls autoPlay loop>
              <source src="https://www.shutterstock.com/shutterstock/videos/1094628365/preview/stock-footage-skyline-panorama-of-the-buildings-of-sheikh-zayed-road-and-difc-day-to-night-transition-timelapse.webm" 
              type="video/mp4" />
              Your browser does not support the video tag.
              <div>
             </div>          
             </video>
            <h2 className="text-xl font-bold mb-2">Project Details</h2>
             <p>Project description goes here.</p>
          </div>
        </div>

        {/* Third Column */}
        <div className="md:w-1/3 mb-4 md:mb-0">
          <div className="aspect-w-16 aspect-h-9">
            <video className="w-full h-full object-cover" controls autoPlay loop>
              <source src="https://www.shutterstock.com/shutterstock/videos/1104298009/preview/stock-footage-doha-qatar-april-timelapse-hyperlapse-video-of-doha-downtown-at-night-with-bright-lights.webm" 
              type="video/mp4" />
              Your browser does not support the video tag.
              <div>
             </div>          
            </video>
            <h2 className="text-xl font-bold mb-2">Project Details</h2>
             <p>Project description goes here.</p>
          </div>
       
        </div>
      </div>
    </div>
    </>
  );
};

export default Projects;