// ContactForm.js

import React from "react";

const Contact = () => {
  return (
    <div className="container mx-auto mt-8 flex">
      {/* Left Column with Image */}
      <div className="w-1/2">
        <img
          src="https://img.freepik.com/free-vector/contact-us-concept-landing-page_52683-12759.jpg?w=740&t=st=1706252849~exp=1706253449~hmac=eeb138e9a2b58885339c3b6226de134cad73f2ca58032c79d633183149eac86b"
          alt="Contact Image"
          className="w-auto h-auto rounded-t-full mt-6"
        />
      </div>

      {/* Right Column with Form */}
      <div className="w-1/2 p-8">
        <h2 className="text-3xl font-semibold mb-4">Contact Us</h2>

        <form className="space-y-4">
          {/* Name Field */}
          <div className="flex flex-col">
            <label htmlFor="name" className="text-sm font-medium">
              Name
            </label>
            <input
              type="text"
              id="name"
              name="name"
              className="border p-2"
              placeholder="Your Name"
            />
          </div>

          {/* Email Field */}
          <div className="flex flex-col">
            <label htmlFor="email" className="text-sm font-medium">
              Email
            </label>
            <input
              type="email"
              id="email"
              name="email"
              className="border p-2"
              placeholder="Your Email"
            />
          </div>

          {/* Address Field */}
          <div className="flex flex-col">
            <label htmlFor="address" className="text-sm font-medium">
              Address
            </label>
            <input
              type="text"
              id="address"
              name="address"
              className="border p-2"
              placeholder="Your Address"
            />
          </div>

          {/* Message Field */}
          <div className="flex flex-col">
            <label htmlFor="message" className="text-sm font-medium">
              Message
            </label>
            <textarea
              id="message"
              name="message"
              rows="4"
              className="border p-2"
              placeholder="Your Message"
            ></textarea>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="bg-blue-500 text-white p-2 rounded hover:bg-blue-600"
          >
            Submit
          </button>
        </form>
      </div>
    </div>
  );
};

export default Contact;
