// AboutUs.js
import React from 'react';
import WebDesignPage from '../OtherPages/WebDesignPage';

const About = () => {
  return (
    <div className="container mx-auto py-6 bg-blue-800 text-white">
      <h1 className="text-3xl font-bold mb-4">About Me</h1>
      <p className="text-white">
        Hello! I am a passionate MERN Stack Developer who recently graduated and is eager to contribute
        to the world of web development. During my studies, I have gained hands-on experience by working on
        various projects, showcasing my skills in MongoDB, Express.js, React.js, and Node.js (MERN Stack).
      </p>
      <p className="text-white mt-4">
        My goal is to continue learning and growing as a developer, staying updated with the latest
        technologies and best practices. I am excited about building scalable and efficient web applications
        that provide a great user experience.
      </p>
      <p className="text-white mt-4">
        Feel free to explore my portfolio and projects to get a better understanding of my skills and
        capabilities. Thank you for visiting!
      </p>
    <WebDesignPage/>
    </div>
  );
};

export default About;
